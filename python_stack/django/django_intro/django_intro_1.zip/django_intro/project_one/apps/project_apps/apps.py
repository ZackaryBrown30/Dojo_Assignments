from django.apps import AppConfig


class ProjectAppsConfig(AppConfig):
    name = 'project_apps'
