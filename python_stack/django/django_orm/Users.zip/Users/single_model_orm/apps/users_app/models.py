from django.db import models

class users(models.Model):
    first_name = models.charfield
