from django.shortcuts import render, redirect 
from apps.semi_apps.models import *

# DO I NEED TO PASS AN ARGUEMENT HERE?
def index(request): #, show_id
    return render(request, 'semi_apps/index.html') # context

def post(request):
    title = request.POST["title"]
    net = request.POST["network"]
    desc = request.POST["description"]
    release = request.POST["release"]
    show = Show.objects.create(title = title, network = net, release_date = release, description = desc)
    return redirect('/show/'+str(show.id))

def show(request, show_id):
    context = {
        'show' : Show.objects.get(id = show_id)
    }
    print(show)
    return render(request, 'semi_apps/show.html', context) 

def all_shows(request):
    context = {
        'all_shows' : Show.objects.all()
    }
    return render(request, 'semi_apps/all_shows.html', context)

def delete(request, show_id):
    dead_show = Show.objects.get(id = show_id)
    dead_show.delete()
    return redirect('/all_shows')

def update_view(request, show_id):
    if request.method =="GET":
        context = {
            "show" : Show.objects.get(id= show_id)
        }
        return render (request, "semi_apps/edit.html", context)

def update(request, show_id):
    if request.method == 'POST':
        subject = Show.objects.get(id = show_id)
        subject.title = request.POST['title']
        subject.network = request.POST['network']
        subject.release_date = request.POST['release']
        subject.description = request.POST['description']
        subject.save()
        return redirect('/all_shows')