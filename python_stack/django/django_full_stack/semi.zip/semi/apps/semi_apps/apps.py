from django.apps import AppConfig


class SemiAppsConfig(AppConfig):
    name = 'semi_apps'
