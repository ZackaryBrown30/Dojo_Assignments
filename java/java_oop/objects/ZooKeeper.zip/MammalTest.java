class MammalTest {
    public static void main(String[] args) {
    Gorilla g = new Gorilla();
    g.throwSomething("Nanar!");
    g.throwSomething("Small Child");
    g.throwSomething("mud pie");
    g.eatBananas();
    g.eatBananas();
    g.climb();
    g.displayEnergyLevel();
    }
}