class BatTest {
    public static void main(String[] args) {
        
        Bat B = new Bat();
        B.attackTown();
        B.attackTown();
        B.attackTown();
        B.eatHumans();
        B.eatHumans();
        B.fly();
        B.fly();
    }
}