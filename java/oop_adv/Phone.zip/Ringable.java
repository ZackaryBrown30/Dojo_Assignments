
    public interface Ringable {
        void ring(String ring);
        void unlock( String unlock);
		String ring();
		String unlock();
    }